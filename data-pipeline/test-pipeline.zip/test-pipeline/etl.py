import sys
import json
import base64
import re
import requests
from os.path import abspath
from pyspark import SparkContext
from pyspark.sql import SparkSession
from pyspark import SQLContext
from pyspark.sql import functions as F
from pyspark.sql.types import StringType
from pyspark.sql.types import StructType
from pyspark.sql.types import LongType
from pyspark.sql.types import IntegerType
from pyspark.sql.types import ArrayType
from pyspark.sql.types import DoubleType
from pyspark.sql.types import FloatType
from pyspark.sql.types import StructField
from pyspark.sql.functions import udf
from pyspark.sql.functions import input_file_name
from datetime import datetime, timedelta

import urllib.parse as urlparse
from urllib import parse
from array import array
from datetime import datetime
from pyspark.sql.functions import explode
from pyspark.sql.functions import explode_outer
from pyspark.sql.functions import col
from pyspark.sql.functions import lit
from pyspark.sql.functions import lower
from user_agents import parse
from pyspark import SparkFiles
import IP2Location.IP2Location as IP2Location
from delta import *

def set_keys(retailer, keys_to_set):
    keys = {}
    for key in keys_to_set:
        keys[key] = config.value.get(retailer).get('key_mappings').get(key)
    return keys

def get_api_token(header, retailer):
    keys = set_keys(retailer, ['api-token', 'Api-Token'])
    api_token = ''
    if header:
        if keys['api-token'] in header and header[keys['api-token']]:
            api_token = header[keys['api-token']]
        elif keys['Api-Token'] in header and header[keys['Api-Token']]:
            api_token = header[keys['Api-Token']]
        else:
            api_token = ''
    return api_token



# headers
def get_header_data(header, body, retailer):
    data = { 'visitor_id': '', 'dw_id': '', 'lpid': '', 'lsid': '', 'lsstart': '', 'lsend': '', '_ga': '', '_gid': '', 'origin': '', 'user_agent': '', 'referer': '', "analytics_id": "", "session_id": "", "expid": ""  }
    keys = set_keys(retailer, list(data.keys()))
    for i in keys:
        # Specific to everlane retailer
        # since visitor_id(vid) is present in both header(with invalid values) and body(with proper value)
        # so we check visitor_id(vid) first in body and then header
        if retailer == 'everlane' and i == 'visitor_id':
            if body and keys[i] in body and body[keys[i]] is not None:
                data[i] = body[keys[i]]
            elif header and keys[i] in header and header[keys[i]] is not None:
                data[i] = header[keys[i]]
        else:
            if header and keys[i] in header and header[keys[i]] is not None:
                if (i == '_ga' or i == '_gid'):
                    data[i] = re.sub('^GA\d+.\d+.', '', header[keys[i]])
                else:
                    data[i] = header[keys[i]]
            elif header and keys[i] is not None and keys[i].capitalize() in header and header[keys[i].capitalize()] is not None:
                if (i == '_ga' or i == '_gid'):
                    data[i] = re.sub('^GA\d+.\d+.', '', header[keys[i]])
                else:
                    data[i] = header[keys[i].capitalize()]
            elif body and keys[i] in body and body[keys[i]] is not None:
                if (i == '_ga' or i == '_gid'):
                    data[i] = re.sub('^GA\d+.\d+.', '', body[keys[i]])
                else:
                    data[i] = body[keys[i]]
    return data


def get_retailer(body_params):
    retailer_name = 'unknown_retailer'
    if body_params:
        body = json.loads(body_params)
        if body:
            if 'retailer_name' in body and body['retailer_name']:
                retailer_name = body['retailer_name']
    return retailer_name


# body
def parse_body(body_params, header_params, retailer):
    body = json.loads(body_params)
    header = json.loads(header_params)
    data = { 'hit_timestamp': '', 'ts': '', 'category': '', 'event': '', 'user_id': '', 'user_email': '', 'order_id': '', 'total': '', 'discount': '', 'retailer_name': '', 'clickstream_service_processed_at': '', 'forget_user': 'no', 'placement_type': '', 'rToken': '', "page_type": "", "product_category": "", "filtersby": "", "size": "", "badge_name": "", "fav_count": "", "position": '', "sort_type": "", "promo_code": "", "availability_status": "", "checkout_remaining_hrs": "", "checkout_mode": "", "wishlist": "", "search_query": "", "search_name": "", "notify": "", "search_id": "", "style_icon_id": "", "style_icon_name": "", "rescue_box_id": "", "quiz_id": "", "answers": "", "goody_box_id": "", "gender": "" }
    keys = set_keys(retailer, list(data.keys()))
    for i in keys:
        if body and keys[i] in body and body[keys[i]] is not None:
            if (i == 'total' or i == 'discount') and type(body[keys[i]]) == dict:
                if 'int' in body[keys[i]] and body[keys[i]]['int'] is not None:
                    data[i] = body[keys[i]]['int']
                elif 'double' in body[keys[i]] and body[keys[i]]['double'] is not None:
                    data[i] = body[keys[i]]['double']
            elif (i == 'filtersby' or i == 'notify' or i == 'answers'):
                data[i] = json.dumps(body[keys[i]])
            else:
                data[i] = body[keys[i]]
        elif header and keys[i] in header and header[keys[i]] is not None:
            if (i == 'total' or i == 'discount') and type(header[keys[i]]) == dict:
                if 'int' in header[keys[i]] and header[keys[i]]['int'] is not None:
                    data[i] = header[keys[i]]['int']
                elif 'double' in header[keys[i]] and header[keys[i]]['double'] is not None:
                    data[i] = header[keys[i]]['double']
            elif (i == 'filtersby' or i == 'notify' or i == 'answers'):
                data[i] = json.dumps(body[keys[i]])
            else:
                data[i] = header[keys[i]]
    return data

def get_campaign_id(body_params, utm_campaign, retailer):
    keys = set_keys(retailer, ['campaign_id'])
    body = json.loads(body_params)
    campaign_id = ''
    if body:
        if keys['campaign_id'] in body and body[keys['campaign_id']]:
            campaign_id = body[keys['campaign_id']]
        else:
            campaign_id = utm_campaign

    return campaign_id

def parse_referer(headers, retailer):
    referer_utm_data = { 'utm_source': '', 'utm_medium': '', 'utm_campaign': '', 'utm_term': '' }
    utm_keys = list(referer_utm_data.keys())
    all_keys = utm_keys
    all_keys.append('referer')
    keys = set_keys(retailer, all_keys)
    if headers and keys['referer'] in headers and headers[keys['referer']]:
        # referer_utm_params = parse_referer(headers[keys['referer']], utm_keys)
        parsed_url = dict(urlparse.parse_qsl(urlparse.urlsplit(headers[keys['referer']]).query))
        del(keys['referer'])
        for i in keys:
            if i in parsed_url:
                referer_utm_data[i] = parsed_url[i]
    return keys, referer_utm_data

def get_utm_values(headers, retailer):
    utm_params = { 'utm_source': '', 'utm_medium': '', 'utm_campaign': '', 'utm_term': '' }
    if headers:
        keys, referer_utm_data = parse_referer(headers, retailer)
        for i in keys:
            if keys[i] in headers and headers[keys[i]] and headers[keys[i]] != 'undefined':
                utm_params[i] = headers[keys[i]]
            elif i in referer_utm_data:
                utm_params[i] = referer_utm_data[i]
    return utm_params


def get_referer_utm(headers, retailer):
    keys, referer_utm_data = parse_referer(headers, retailer)
    return referer_utm_data


def encode_source_ip(request_context, retailer):
    keys = set_keys(retailer, ['sourceIp'])
    if request_context and 'identity' in request_context and request_context['identity'] and keys['sourceIp'] in request_context['identity']:
        return base64.b64encode(str.encode(request_context['identity'][keys['sourceIp']])).decode()
    else:
        return ''

def processed_time():
    return int(datetime.timestamp(datetime.now()) * 1000)

def assign_products_data(product_data, keys):
    product = { 'sku_id': '', 'variant_id': '', 'price': '', 'sale_price': '', 'quantity': '', 'currency': '' }
    for i in keys:
        if product_data and keys[i] in product_data and product_data[keys[i]] is not None:
            if (i == 'price' or i == 'sale_price') and type(product_data[keys[i]]) == dict:
                if 'int' in product_data[keys[i]] and product_data[keys[i]]['int'] is not None:
                    product[i] = product_data[keys[i]]['int']
                elif 'double' in product_data[keys[i]] and product_data[keys[i]]['double'] is not None:
                    product[i] = product_data[keys[i]]['double']
            else:
                product[i] = product_data[keys[i]]
    return product

def products_arr(body_params, retailer):
    product_h = { 'sku_id': '', 'variant_id': '', 'price': '', 'sale_price': '', 'quantity': '', 'currency': '' }
    if body_params:
        body = json.loads(body_params)
        keys = set_keys(retailer, list(product_h.keys()))
        products = []
        if 'products' in body and body['products']:
            for product_tmp in body['products']:
                if 'struct' in product_tmp and product_tmp['struct']:
                    product_tmp = product_tmp['struct']
                product = assign_products_data(product_tmp, keys)
                products.append(product)
        else:
            product = assign_products_data(body, keys)
            products.append(product)
    else:
        products.append(product_h)
    return products


def get_dwid(dwid, user_id):
    if dwid:
        return dwid
    else:
        return user_id
def get_lpid(data):
    if '-' not in data['lpid']:
        return data['_ga']
    else:
        return data['lpid']

def get_user_id(dwid, user_id):
    if user_id:
        return user_id
    else:
        return dwid

def parse_user_agent(ua_string):
    user_agent = parse(ua_string)
    if user_agent.is_pc:
        device_type = 'desktop'
    elif user_agent.is_mobile:
        device_type = 'mweb'
    elif user_agent.is_tablet:
        device_type = 'tablet'
    else:
        device_type = 'other'
    return device_type

def parse_origin(origin):
    geo = ''
    if origin:
        splitted_origin = origin.rpartition('.')[-1].rpartition('/')[-1]
        if splitted_origin == 'com':
            geo = 'us'
        else:
            geo = splitted_origin

    return geo

def source_ip_geo(request_context, retailer):
    keys = set_keys(retailer, ['sourceIp'])
    geo = { 'country': '', 'region': '', 'city': '', 'latitude': '', 'longitude': '' }
    if request_context and 'identity' in request_context and request_context['identity'] and keys['sourceIp'] in request_context['identity']:
        database = IP2Location.IP2Location(SparkFiles.get('IP2LOCATION-LITE-DB5.IPV6.BIN'))
        try:
            response = database.get_all(request_context['identity'][keys['sourceIp']])
            geo = { 'country': response.country_long, 'region': response.region, 'city': response.city, 'latitude': response.latitude, 'longitude': response.longitude }
        except:
            geo = { 'country': '', 'region': '', 'city': '', 'latitude': '', 'longitude': '' }

    return geo



############  ################
args = sys.argv

source = args[1]
destination = args[2]
latest_data = args[3]
mode = args[4]
ip_db = args[5]
clickstream_retailer_config = args[6]
schedule_period = args[7]
query_params = args[8]

warehouse_location = abspath('spark-warehouse')

sparkSession = (SparkSession
                .builder
                .appName('PixelRawUserRecordStore')
                .config("spark.sql.warehouse.dir", warehouse_location)
                .config("spark.default.parallelism", 400)
                .enableHiveSupport()
                .getOrCreate())

sparkSession.sparkContext.addFile(ip_db)


utm_params_schema = StructType([
    StructField("utm_source", StringType(), True),
    StructField("utm_medium", StringType(), True),
    StructField("utm_campaign", StringType(), True),
    StructField("utm_term", StringType(), True)
])

get_api_token_udf = udf(get_api_token, StringType())


get_header_data_udf = udf(get_header_data, StructType([
    StructField("visitor_id", StringType(), True),
    StructField("dw_id", StringType(), True),
    StructField("lpid", StringType(), True),
    StructField("lsid", StringType(), True),
    StructField("lsstart", StringType(), True),
    StructField("lsend", StringType(), True),
    StructField("_ga", StringType(), True),
    StructField("_gid", StringType(), True),
    StructField("origin", StringType(), True),
    StructField("user_agent", StringType(), True),
    StructField("referer", StringType(), True),
    StructField("analytics_id", StringType(), True),
    StructField("session_id", StringType(), True),
    StructField("expid", StringType(), True)
]))

get_retailer_udf = udf(get_retailer, StringType())

parse_body_udf = udf(parse_body, StructType([
    StructField("hit_timestamp", LongType(), True),
    StructField("ts", StringType(), True),
    StructField("category", StringType(), True),
    StructField("event", StringType(), True),
    StructField("user_id", StringType(), True),
    StructField("user_email", StringType(), True),
    StructField("order_id", StringType(), True),
    StructField("total", StringType(), True),
    StructField("discount", StringType(), True),
    StructField("retailer_name", StringType(), True),
    StructField("clickstream_service_processed_at", LongType(), True),
    StructField("forget_user", StringType(), True),
    StructField("placement_type", StringType(), True),
    StructField("rToken", StringType(), True),
    StructField("page_type", StringType(), True),
    StructField("product_category", StringType(), True),
    StructField("filtersby", StringType(), True),
    StructField("size", StringType(), True),
    StructField("badge_name", StringType(), True),
    StructField("fav_count", StringType(), True),
    StructField("position", StringType(), True),
    StructField("sort_type", StringType(), True),
    StructField("promo_code", StringType(), True),
    StructField("availability_status", StringType(), True),
    StructField("checkout_remaining_hrs", StringType(), True),
    StructField("checkout_mode", StringType(), True),
    StructField("wishlist", StringType(), True),
    StructField("search_query", StringType(), True),
    StructField("search_name", StringType(), True),
    StructField("notify", StringType(), True),
    StructField("search_id", StringType(), True),
    StructField("style_icon_id", StringType(), True),
    StructField("style_icon_name", StringType(), True),
    StructField("rescue_box_id", StringType(), True),
    StructField("quiz_id", StringType(), True),
    StructField("answers", StringType(), True),
    StructField("goody_box_id", StringType(), True),
    StructField("gender", StringType(), True)
]))

get_campaign_id_udf = udf(get_campaign_id, StringType())

get_utm_values_udf = udf(get_utm_values, utm_params_schema)

get_referer_utm_udf = udf(get_referer_utm, utm_params_schema)

encode_source_ip_udf = udf(encode_source_ip, StringType())

processed_time_udf = udf(processed_time, LongType())

products_arr_udf = udf(products_arr, ArrayType(
    StructType([
        StructField("sku_id", StringType(), True),
        StructField("variant_id", StringType(), True),
        StructField("price", StringType(), True),
        StructField("sale_price", StringType(), True),
        StructField("quantity", StringType(), True),
        StructField("currency", StringType(), True)
    ])
))

get_dwid_udf = udf(get_dwid, StringType())

get_lpid_udf = udf(get_lpid, StringType())

get_user_id_udf = udf(get_user_id, StringType())

parse_user_agent_udf = udf(parse_user_agent, StringType())

parse_origin_udf = udf(parse_origin, StringType())

source_ip_geo_udf = udf(source_ip_geo, StructType([
    StructField("country", StringType(), True),
    StructField("region", StringType(), True),
    StructField("city", StringType(), True),
    StructField("latitude", StringType(), True),
    StructField("longitude", StringType(), True)
]))

sparkSession.sparkContext.addFile(ip_db)
RetailerConfigFile = sparkSession.read.json(clickstream_retailer_config, multiLine=True)
clickstream_retailer_config_json = json.loads(RetailerConfigFile.toJSON().first())
config = sparkSession.sparkContext.broadcast(clickstream_retailer_config_json)
retailers = sparkSession.sparkContext.broadcast(list(config.value.keys()))

# To process the specific days data and partition based on the schedule_period
if query_params:
    params = json.loads(query_params)
    retailer = params.get('retailer')
    from_date = params.get('from_date')
    to_date = params.get('to_date')
    if from_date and to_date:
        from_date = datetime.strptime(from_date, '%m/%d/%Y')
        to_date = datetime.strptime(to_date, '%m/%d/%Y')

# To process the hourly data and partition based on hour

df = sparkSession.read.format("s3selectJson").load(source).select(['headers', 'body', 'requestContext'])

if not 'requestContext' in df.columns:
    df = df.withColumn('requestContext', F.lit(''))

data = df.withColumn('retailer', lower(get_retailer_udf(F.to_json(df["body"])))).filter(F.col('retailer') != 'unknown_retailer')
if retailer:
    data = data.filter(F.col('retailer') == retailer)

modified_df = data.withColumn("api_token", get_api_token_udf(df["headers"], F.col('retailer'))) \
                  .withColumn("body_data", parse_body_udf(F.to_json(df["body"]), F.to_json(df["headers"]), F.col('retailer'))) \
                  .withColumn("header_data", get_header_data_udf(df["headers"], df["body"], F.col('retailer'))) \
                  .withColumn("lpid", get_lpid_udf(get_header_data_udf(df["headers"], df["body"], F.col('retailer')))) \
                  .withColumn("dw_id", get_dwid_udf(get_header_data_udf(df["headers"], df["body"], F.col('retailer'))["dw_id"], parse_body_udf(F.to_json(df["body"]), F.to_json(df["headers"]), F.col('retailer'))["user_id"])) \
                  .withColumn("locale", lower(parse_origin_udf(get_header_data_udf(df["headers"], df["body"], F.col('retailer'))["origin"]))) \
                  .withColumn("source_ip_data", source_ip_geo_udf(df["requestContext"], F.col('retailer'))) \
                  .withColumn("device_type", parse_user_agent_udf(get_header_data_udf(df["headers"], df["body"], F.col('retailer'))["user_agent"])) \
                  .withColumn("user_id", get_user_id_udf(get_header_data_udf(df["headers"], df["body"], F.col('retailer'))["dw_id"], parse_body_udf(F.to_json(df["body"]), F.to_json(df["headers"]), F.col('retailer'))["user_id"]))    \
                  .withColumn("campaign_id", lower(get_campaign_id_udf(F.to_json(df["body"]), get_utm_values_udf(df["headers"], F.col('retailer'))["utm_campaign"], F.col('retailer')))) \
                  .withColumn("utm_data", get_utm_values_udf(df["headers"], F.col('retailer'))) \
                  .withColumn("referer_utm_data", get_referer_utm_udf(df["headers"], F.col('retailer'))) \
                  .withColumn("source_ip", encode_source_ip_udf(df["requestContext"], F.col('retailer'))) \
                  .withColumn("product", explode_outer(products_arr_udf(F.to_json(df["body"]), F.col('retailer')))) \
                  .withColumn("processed_timestamp", processed_time_udf())

select_fields = []

header_data = [F.col('header_data.lsid'), F.col('header_data.lsstart').cast("long"), F.col('header_data.lsend').cast("long"), \
               F.col('header_data._ga'), F.col('header_data._gid'), lower(F.col('header_data.origin')).alias('origin'), \
               F.col('header_data.user_agent'), lower(F.col('header_data.referer')).alias('referer'), F.col('header_data.visitor_id'), \
               F.col('header_data.analytics_id'), lower(F.col('header_data.session_id')).alias('session_id'), lower(F.col('header_data.expid')).alias('expid')]

body_data = [F.col('body_data.hit_timestamp'), F.col('body_data.ts'), F.col('body_data.clickstream_service_processed_at'), lower(F.col('body_data.category')).alias('category'), \
             lower(F.col('body_data.event')).alias('event'),  F.col('body_data.placement_type'), F.col('body_data.rToken'), \
             lower(F.col('body_data.user_email')).alias('user_email'), F.col('body_data.order_id').cast("long"), F.col('body_data.total').cast("decimal(10, 2)"), \
             F.col('body_data.discount').cast("decimal(10, 2)"), F.col('body_data.forget_user'), F.col('body_data.filtersby'), F.col('body_data.fav_count').cast("integer"), \
             F.col('body_data.promo_code'), F.col('body_data.wishlist'), F.col('body_data.search_name'), F.col('body_data.answers'), F.col('body_data.sort_type'), \
             F.col('body_data.checkout_remaining_hrs'), F.col('body_data.notify'), F.col('body_data.size'), F.col('body_data.goody_box_id'), F.col('body_data.search_query'), \
             F.col('body_data.rescue_box_id'), F.col('body_data.checkout_mode'), F.col('body_data.product_category'), F.col('body_data.style_icon_name'), \
             F.col('body_data.availability_status'), F.col('body_data.page_type'), F.col('body_data.style_icon_id'), F.col('body_data.badge_name'), F.col('body_data.position').cast("integer"), \
             F.col('body_data.quiz_id'), F.col('body_data.search_id'), lower(F.col('body_data.gender')).alias('gender')]

utm_data = [lower(F.col('utm_data.utm_source')).alias('utm_source'), lower(F.col('utm_data.utm_medium')).alias('utm_medium'), \
            lower(F.col('utm_data.utm_campaign')).alias('utm_campaign'), lower(F.col('utm_data.utm_term')).alias('utm_term')]

referer_utm_data = [lower(F.col('referer_utm_data.utm_source')).alias('referer_utm_source'), lower(F.col('referer_utm_data.utm_medium')).alias('referer_utm_medium'), \
                    lower(F.col('referer_utm_data.utm_campaign')).alias('referer_utm_campaign'), lower(F.col('referer_utm_data.utm_term')).alias('referer_utm_term')]

source_ip_data = [lower(F.col('source_ip_data.country')).alias('geo_country'), lower(F.col('source_ip_data.region')).alias('geo_region'), \
                  lower(F.col('source_ip_data.latitude')).alias('geo_latitude'), lower(F.col('source_ip_data.longitude')).alias('geo_longitude'), lower(F.col('source_ip_data.city')).alias('geo_city')]

product_data = [F.col('product.sku_id'), F.col('product.variant_id'), F.col('product.price').cast("decimal(10, 2)"), \
                F.col('product.sale_price').cast("decimal(10, 2)"), F.col('product.quantity').cast("integer"), F.col('product.currency')]

others = [F.col('api_token'), F.col('dw_id'), F.col('lpid'), F.col('locale'), F.col('device_type'), F.col('user_id'), F.col('retailer'), F.col('campaign_id'), \
          F.col('source_ip'), F.col('processed_timestamp').cast("long"), F.col('year'), F.col('month'), F.col('day')]

select_fields.extend(header_data + body_data + utm_data + referer_utm_data + source_ip_data + product_data + others)

modified_df.write.partitionBy("retailer").parquet(destination,mode=mode)

# modified_df.write.partitionBy("retailer").format("delta").mode("overwrite").save(destination)
