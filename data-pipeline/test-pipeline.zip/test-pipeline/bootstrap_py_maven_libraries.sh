#!/bin/bash

sudo python3 -m pip install boto3==1.18.34 requests==2.26.0 ua-parser==0.10.0 user-agents==2.2.0 IP2Location==8.6.2

echo " " >> /home/hadoop/.bash_profile
echo "export PYSPARK_PYTHON=/usr/bin/python3" >> /home/hadoop/.bash_profile
